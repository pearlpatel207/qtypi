# qtypi
qtypi (as in cutiepie) is my python library for Quantum Computing
[imo there's nothing cute about this library, except for this author :p]
